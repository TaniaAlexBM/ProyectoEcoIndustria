<div data-colibri-id="7-h5" class="d-flex align-items-center text-lg-center text-md-center text-center justify-content-lg-center justify-content-md-center justify-content-center style-5 style-local-7-h5 position-relative h-element">
  <?php $component = \ColibriWP\Theme\View::getData( 'component' ); ?>
                        <?php  $component->printImageLogo("style-5");?>
                      <?php $component->printTextLogo(); ?>
</div>
