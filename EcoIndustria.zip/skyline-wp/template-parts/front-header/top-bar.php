<div class="h-section-grid-container h-section-fluid-container" data-colibri-id="7-h18">
  <div data-colibri-id="7-h19" class="h-row-container style-19 style-local-7-h19 h-hide-sm position-relative">
    <div class="h-section-boxed-container gutters-row-lg-0 gutters-row-md-0 gutters-row-0 gutters-row-v-lg-0 gutters-row-v-md-0 gutters-row-v-0">
      <div class="h-row justify-content-lg-center justify-content-md-center justify-content-center align-items-lg-stretch align-items-md-stretch align-items-stretch gutters-col-lg-0 gutters-col-md-0 gutters-col-0 gutters-col-v-lg-0 gutters-col-v-md-0 gutters-col-v-0">
        <div class="h-column h-column-container d-flex h-col-none style-20-outer style-local-7-h20-outer">
          <div data-colibri-id="7-h20" class="d-flex h-flex-basis h-column__inner h-px-lg-0 h-px-md-0 h-px-0 v-inner-lg-0 v-inner-md-0 v-inner-0 style-20 style-local-7-h20 position-relative">
            <div class="w-100 h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-center align-self-md-center align-self-center">
              <?php colibriwp_theme()->get('top-bar-list-icons')->render(); ?>
            </div>
          </div>
        </div>
        <div class="h-column h-column-container d-flex h-col-none style-22-outer style-local-7-h22-outer">
          <div data-colibri-id="7-h22" class="d-flex h-flex-basis h-column__inner h-px-lg-0 h-px-md-0 h-px-0 v-inner-lg-0 v-inner-md-0 v-inner-0 style-22 style-local-7-h22 position-relative">
            <div class="w-100 h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-center align-self-md-center align-self-center">
              <?php colibriwp_theme()->get('top-bar-social-icons')->render(); ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
